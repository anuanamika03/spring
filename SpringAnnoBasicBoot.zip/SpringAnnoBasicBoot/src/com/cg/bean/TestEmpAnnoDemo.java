package com.cg.bean;

import org.springframework.boot.SpringApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

@ComponentScan(basePackages="com.cg.bean")
public class TestEmpAnnoDemo {
	public static void main(String[] args) {
	
		ApplicationContext ctx=SpringApplication.run(TestEmpAnnoDemo.class, args);
	
		Employee e1= (Employee)ctx.getBean("vaiEmp1");
		System.out.println(e1);
		
		System.out.println("-------------------------------------");
		
		Emp e2=(Emp)ctx.getBean("e2");
		System.out.println(e2);
		
		System.out.println("-------------------------------------");
		User u1=(User)ctx.getBean("u1");
		System.out.println(u1);
		
	}

}
