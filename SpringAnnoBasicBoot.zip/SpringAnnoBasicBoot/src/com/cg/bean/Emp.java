package com.cg.bean;
import java.util.ArrayList;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
@Component("e2")
public class Emp {
	@Value("999")// this annotation is used for  single value
	private int empId;
	@Value("sheetal")
	private String empName;
	@Value("40000.0")
	private float empSal;
	
	@Resource(name="getAddList")//this annotation is for array list
	private ArrayList<Address>empadd;
	
	public Emp() {}
	
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public float getEmpSal() {
		return empSal;
	}
	public void setEmpSal(float empSal) {
		this.empSal = empSal;
	}
	public ArrayList<Address> getAdd() {
		return empadd;
	}
	public void setAdd(ArrayList<Address> add) {
		this.empadd = add;
	}

	@Override
	public String toString() {
		return "Emp [empId=" + empId + ", empName=" + empName + ", empSal=" + empSal + ", add=" + empadd + "]";
	}
	
	
	
}
