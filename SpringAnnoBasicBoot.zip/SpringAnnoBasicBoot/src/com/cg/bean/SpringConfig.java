package com.cg.bean;//this is a config class for @resource 

import java.util.ArrayList;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;

@Configuration
public class SpringConfig {
	@Bean
	public ArrayList<Address>getAddList()
	{
		Address ad1=new Address();
		ad1.setCity("chennai");
		ad1.setState("gujrat");
		ad1.setZipcode(333);
		
		Address ad2=new Address();
		ad2.setCity("mumbai");
		ad2.setState("maharashtra");
		ad2.setZipcode(222);
		
		
		ArrayList<Address>adList=new ArrayList<Address>();
		return adList;
	}
		
		//-------------------------------------------------
		
		@Bean
		public Address getOffAddress2()

		{
			Address ad= new Address();
			ad.setCity("chennai");
			ad.setState("tamilnadu");
			ad.setZipcode(1233456);
			return ad;
		}	
			
			//-------------------------------------------
		@Bean
		public static  PropertySourcesPlaceholderConfigurer propertyConfigInDev() {
			return new PropertySourcesPlaceholderConfigurer();
		}
		
			
			
			
			
	}

