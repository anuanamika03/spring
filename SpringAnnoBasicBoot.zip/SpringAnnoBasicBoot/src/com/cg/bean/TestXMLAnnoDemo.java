package com.cg.bean;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestXMLAnnoDemo {

	public static void main(String[] args) {
		ApplicationContext ctx=new ClassPathXmlApplicationContext("CgXMLAnno.xml");
		IGreet g1=(IGreet)ctx.getBean("obj1");
		System.out.println(g1.GreetMe());
		
		System.out.println("-------------------------------------");
		IGreet g2=(IGreet)ctx.getBean("obj2");
		System.out.println(g2.GreetMe());
		
		
	}

}
