package com.cg.beans;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestSpringReadpropDemo {

	public static void main(String[] args) {
		ApplicationContext ctx= new ClassPathXmlApplicationContext("bean.xml");
		User myCredentials =(User)ctx.getBean("user1");
		System.out.println(myCredentials);
	}

}
