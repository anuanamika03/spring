package com.cg.bean;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.beans.factory.BeanNameAware;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.NoSuchBeanDefinitionException;

public class BirthDayGreeting implements IGreet ,BeanNameAware,BeanFactoryAware,DisposableBean,InitializingBean
{
	String firstName;
	
	public BirthDayGreeting(String firstName) {
		super();
		this.firstName = firstName;
	}
	public BirthDayGreeting()
	{
		System.out.println(" In BirthDayGreeting " + " constructor ");
	}
	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
		System.out.println("set firstNameCalled");
	}

	@Override
	public String GreetMe() {
	return "happy birthday "+ firstName;
		
	}
	@Override
	public void setBeanName(String beanName) {
		System.out.println(" In setBeanName() called..." + beanName);
		
	}
	@Override
	public void setBeanFactory(BeanFactory bf) throws BeansException {
		System.out.println("---------------in setBeanFactory()-------------" +bf.toString());
	}
	@Override
	public void afterPropertiesSet() throws Exception {
		
		System.out.println(" this is called after firstName");
	}
	@Override
	public void destroy() throws Exception {
		
		System.out.println("destroy is called-----------");
		
	}
	 //how to write your own functions
	public void cgInit() {
		System.out.println("this is custom cg init");
	}
		
	public void cgDestroy() {
		System.out.println("this is custom cg destroy");
	}	
		
		

		
	}
	
