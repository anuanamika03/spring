package com.cg.bean;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestSpringAppContextContainerDemo {

	public static void main(String[] args) {
	
		ApplicationContext ctx=new ClassPathXmlApplicationContext("cg.xml");//initialise the containetr
		System.out.println("........Spring Container was initialized ");
		System.out.println("........Birthday wish---------------- ");
		IGreet g1=(IGreet)ctx.getBean("obj1");
		System.out.println(g1.GreetMe());
		System.out.println(g1.hashCode());
		
		IGreet g3=(IGreet)ctx.getBean("obj1");
		System.out.println(g3.GreetMe());
		System.out.println(g3.hashCode());
		
		
		System.out.println("........New Year wish---------------- ");
		IGreet g2=(IGreet)ctx.getBean("obj2");
		System.out.println(g2.GreetMe());
		System.out.println(g2.hashCode());
		
		System.out.println("........New Year wish---------------- ");
		IGreet g4=(IGreet)ctx.getBean("obj2");
		System.out.println(g4.GreetMe());
		System.out.println(g4.hashCode());
		

		System.out.println("........New Year wish---------------- ");
		IGreet g5=(IGreet)ctx.getBean("obj2");
		System.out.println(g5.GreetMe());
		System.out.println(g5.hashCode());
		
		
		
		
	}
	
}
