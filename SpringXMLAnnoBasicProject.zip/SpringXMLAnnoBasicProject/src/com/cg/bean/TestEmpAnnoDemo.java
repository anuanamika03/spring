package com.cg.bean;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestEmpAnnoDemo {

	public static void main(String[] args) {
		
		ApplicationContext ctx=new ClassPathXmlApplicationContext("CgXMLAnno.xml");
		
		Employee e1= (Employee)ctx.getBean("vaiEmp1");
		System.out.println(e1);
		
		System.out.println("-------------------------------------");
		
		Emp e2=(Emp)ctx.getBean("e2");
		System.out.println(e2);
		
		
	}

}
