package com.cg.bean;

import org.springframework.beans.factory.annotation.Value;

public class NewYearWish  implements IGreet{
	//automatic setter injection using annotation
	@Value("anamika")
	String firstName;
	@Value("2020")
	int year;
	
	public NewYearWish(String firstName, int year) {
		super();
		this.firstName = firstName;
		this.year = year;
		System.out.println(" in new year wish parameter contructor");
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
		System.out.println("set year called");
	}
	public NewYearWish() {
		System.out.println(" In NewYear wish " + " constructor ");
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
		System.out.println(" setFirstNameCalled");
	}

	@Override
	public String GreetMe() {
	return "happy  new year " +year + " : "+ firstName;
		
	}

}


