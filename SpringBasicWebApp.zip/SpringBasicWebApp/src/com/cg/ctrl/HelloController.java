package com.cg.ctrl;
import java.time.LocalDate;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
@Controller//same as component annotation but signifies that it is a controller component
@RequestMapping("myCtrl")
	public class HelloController
	{
		@RequestMapping(value="/hello")
		public ModelAndView showMsg() {
			LocalDate today=LocalDate.now();
			 ModelAndView mdv=new ModelAndView("Hello" , "tdObj" ,today);
			 return mdv;//1st prameter view name = hello 
			 //2nd parameter model object
			 
		}
	
	}
