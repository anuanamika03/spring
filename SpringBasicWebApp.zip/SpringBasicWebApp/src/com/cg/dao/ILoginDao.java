package com.cg.dao;

import java.util.ArrayList;

import com.cg.dto.Login;
import com.cg.dto.RegisterDto;

public interface ILoginDao 
{
		public boolean isUserExist(String usn);//to check whether user exist or not
		public Login validateUser(Login login);//check correct password details
		public RegisterDto insertUserDetails(RegisterDto userDetails);
		public ArrayList<RegisterDto>getAllUserDetails();
		public RegisterDto deleteUser(String usn);
}
