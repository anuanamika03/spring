package com.cg.bean;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestEmpDemo {

	public static void main(String[] args) {
		ApplicationContext ctx=new ClassPathXmlApplicationContext("cgbeans.xml");//object constructor getter setter method created
		
		/*Employee emp1=(Employee)ctx.getBean("vaiObj");
		System.out.println("------------emp info---------------");
		System.out.println(" ID :"+emp1.getEmpId()+ " Name :" +emp1.getEmpName()+"  Salary "+emp1.getEmpSal()
		+ " Emp Address : " +emp1.getEmpAdd().getState()+ " ," +emp1.getEmpAdd().getCity()+" , "
		+emp1.getEmpAdd().getZipcode());
*/
		
		System.out.println("---------------------------");
		Emp emp2=(Emp)ctx.getBean("AnamikaObj");
		System.out.println("------------emp info---------------");
		System.out.println(" ID :"+emp2.getEmpId()+ " Name :" +emp2.getEmpName()+"  Salary "+emp2.getEmpSal()
		+ " Emp Address : " +emp2.getAdd());

}
}