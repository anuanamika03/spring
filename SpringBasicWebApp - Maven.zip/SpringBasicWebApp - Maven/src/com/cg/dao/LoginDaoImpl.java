package com.cg.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.dto.Login;
import com.cg.dto.RegisterDto;
@Repository ("loginDao")//this is a dao class so use repository
@Transactional
public class LoginDaoImpl implements ILoginDao{

	@PersistenceContext
	EntityManager entityManager=null;
	
	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Override
	public boolean isUserExist(String usn)
	{
		Login usr =entityManager.find(Login.class, usn);
		if(usr!=null)
		{
			return true;
			
		}
		else
		{
		return false;
			}
	}
	@Override
	public Login validateUser(Login login)	
	{
		Login usr=entityManager.find(Login.class, login.getUsername());
		
		return usr;
	}

	@Override
	public RegisterDto insertUserDetails(RegisterDto userDetails)
	{		Login logObj=new Login();
	logObj.setUsername(userDetails.getUname());
	logObj.setPassword(userDetails.getPwd());
	    entityManager.persist(userDetails);
		entityManager.persist(logObj);
		entityManager.flush();
		RegisterDto rd=entityManager.find(RegisterDto.class, userDetails.getUname());
		return rd;
	}

	@Override
	public ArrayList<RegisterDto> getAllUserDetails() {
		String qry="SELECT reg FROM RegisterDto reg ";
		TypedQuery<RegisterDto> tq=entityManager.
				createQuery(qry,RegisterDto.class);
		ArrayList<RegisterDto> uList=(ArrayList)tq.getResultList();
		return uList;
	}

	@Override
	public RegisterDto deleteUser(String usn) {
	RegisterDto redDto=entityManager.find(RegisterDto.class, usn);
	Login logDto=entityManager.find(Login.class, usn);
	entityManager.remove(redDto);
	entityManager.remove(logDto);
	entityManager.flush();
		return redDto;
	}

}
